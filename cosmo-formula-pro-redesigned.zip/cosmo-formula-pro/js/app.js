document.addEventListener("DOMContentLoaded", () => {
  const search = document.querySelector(".search-box input");

  if (search) {
    search.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        const value = search.value.trim();

        if (value) {
          window.location.href =
            "products.html?search=" + encodeURIComponent(value);
        }
      }
    });
  }
});
