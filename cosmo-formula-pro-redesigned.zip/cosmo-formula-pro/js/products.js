const products = [
  {
    id: "c-mite-soap",
    name: "C-MITE Soap",
    name_bn: "সি-মাইট সাবান",
    category: "soap",
    weight: "75 g",
    type: "Active / Medicated Soap",
    ingredients: ["Permethrin", "Cetrimide", "Aloe Vera"]
  }
];

const params = new URLSearchParams(window.location.search);
const category = params.get("category");
const search = params.get("search");

const list = document.getElementById("productList");
const title = document.getElementById("pageTitle");

let filtered = products;

if (category) {
  filtered = products.filter(p => p.category === category);

  const titles = {
    soap: "🧼 সাবান",
    shampoo: "🧴 শ্যাম্পু",
    cream: "🧴 ক্রিম",
    facewash: "🫧 ফেসওয়াশ",
    baby: "👶 বেবি কেয়ার",
    laundry: "🧺 লন্ড্রি",
    haircare: "💇 হেয়ার কেয়ার",
    bodycare: "🧴 বডি কেয়ার",
    other: "🧪 অন্যান্য"
  };

  title.textContent = titles[category] || "পণ্যসমূহ";
}

if (search) {
  filtered = products.filter(p =>
    (p.name + " " + p.name_bn + " " + p.ingredients.join(" "))
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  title.textContent = "🔍 Search Results";
}

if (filtered.length === 0) {
  list.innerHTML = `
    <div style="grid-column:1/-1;background:white;padding:25px;border-radius:18px;text-align:center">
      <div style="font-size:35px">📦</div>
      <h3>এখনও কোনো পণ্য যোগ করা হয়নি</h3>
      <p style="color:#64748b;margin-top:8px">
        এই ক্যাটাগরিতে আমরা ধাপে ধাপে নতুন ফর্মুলা যোগ করব।
      </p>
    </div>
  `;
} else {
  filtered.forEach(product => {
    const card = document.createElement("a");

    card.href = `product-details.html?id=${product.id}`;
    card.className = "category-card";

    card.innerHTML = `
      <div class="category-icon">🧼</div>
      <div>
        <h3>${product.name}</h3>
        <p>${product.name_bn} • ${product.weight}</p>
        <p>${product.ingredients.join(" • ")}</p>
      </div>
    `;

    list.appendChild(card);
  });
}
