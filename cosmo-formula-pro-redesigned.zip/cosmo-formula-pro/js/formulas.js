const formulas = [
  {
    id: "c-mite-soap",
    name: "C-MITE Soap",
    category: "সাবান",
    icon: "🧼",
    status: "Reference",
    description: "Permethrin, Cetrimide ও Aloe Vera সমৃদ্ধ medicated soap."
  },

  {
    id: "transparent-glycerin-soap",
    name: "Transparent Glycerin Soap",
    category: "সাবান",
    icon: "🧼",
    status: "Development",
    description: "স্বচ্ছ glycerin soap formulation — development reference."
  },

  {
    id: "mild-shampoo",
    name: "Mild Shampoo",
    category: "শ্যাম্পু",
    icon: "🧴",
    status: "Development",
    description: "মৃদু cleansing shampoo formulation — development reference."
  },

  {
    id: "basic-facewash",
    name: "Basic Face Wash",
    category: "ফেসওয়াশ",
    icon: "🫧",
    status: "Development",
    description: "Gentle facial cleanser formulation — development reference."
  },

  {
    id: "body-lotion",
    name: "Basic Body Lotion",
    category: "বডি কেয়ার",
    icon: "🧴",
    status: "Development",
    description: "Moisturizing body lotion formulation — development reference."
  },

  {
    id: "liquid-detergent",
    name: "Liquid Detergent",
    category: "লন্ড্রি",
    icon: "🧺",
    status: "Development",
    description: "Laundry cleaning formulation — development reference."
  }
];

const list = document.getElementById("formulaList");
const search = document.getElementById("formulaSearch");

function renderFormulas(items) {

  if (!items.length) {
    list.innerHTML = `
      <div style="
        grid-column:1/-1;
        background:white;
        padding:25px;
        border-radius:18px;
        text-align:center;
      ">
        <div style="font-size:35px">🔎</div>
        <h3>কোনো ফর্মুলা পাওয়া যায়নি</h3>
      </div>
    `;
    return;
  }

  list.innerHTML = items.map(formula => `
    <a
      href="product-details.html?id=${formula.id}"
      class="category-card"
    >
      <div class="category-icon">${formula.icon}</div>

      <div>
        <h3>${formula.name}</h3>
        <p>${formula.category}</p>
        <p>${formula.description}</p>

        <small style="
          display:inline-block;
          margin-top:6px;
          color:#0284c7;
          font-weight:bold;
        ">
          ${formula.status}
        </small>
      </div>
    </a>
  `).join("");
}

renderFormulas(formulas);

search.addEventListener("input", () => {

  const value = search.value.toLowerCase().trim();

  const filtered = formulas.filter(formula =>
    (
      formula.name +
      " " +
      formula.category +
      " " +
      formula.description
    ).toLowerCase().includes(value)
  );

  renderFormulas(filtered);
});
