const product = {
  name: "C-MITE Soap",
  name_bn: "সি-মাইট সাবান",
  brand: "Crescent Pharma",
  pack: "75 g",
  type: "Medicated / Active Soap",

  composition: [
    ["Permethrin", "1% w/w", "Antiparasitic active"],
    ["Cetrimide", "0.5% w/w", "Antiseptic"],
    ["Aloe Vera", "2% w/w", "Skin-conditioning / soothing"],
    ["Soap Noodles", "q.s.", "Soap base"],
    ["Titanium Dioxide", "Not specified", "Colour / opacifying agent"]
  ],

  uses: [
    "Scabies infestation",
    "Head lice / lice infestation"
  ],

  precautions: [
    "শুধুমাত্র বাহ্যিক ব্যবহারের জন্য।",
    "চোখ, নাক, মুখ ও mucous membrane এড়িয়ে চলুন।",
    "গিলে ফেলবেন না।",
    "শিশুদের নাগালের বাইরে রাখুন।",
    "গর্ভাবস্থা বা breastfeeding-এর ক্ষেত্রে চিকিৎসকের পরামর্শ নিন।",
    "ব্যবহারের পর তীব্র জ্বালা বা অস্বস্তি হলে চিকিৎসকের পরামর্শ নিন।"
  ],

  sideEffects: [
    "জ্বালাপোড়া",
    "চুলকানি",
    "লালভাব",
    "ত্বক শুষ্ক হওয়া"
  ]
};

const root = document.getElementById("productDetails");

root.innerHTML = `
<section class="product-hero">
  <div class="product-icon">🧼</div>

  <div>
    <div class="medical-badge">⚕ ACTIVE / MEDICATED</div>
    <h1>${product.name}</h1>
    <p>${product.name_bn} • ${product.pack}</p>
    <small>${product.brand}</small>
  </div>
</section>

<section class="details-section">
  <h2>🧪 Composition</h2>

  <div class="composition-list">
    ${product.composition.map(item => `
      <div class="composition-item">
        <strong>${item[0]}</strong>
        <span>${item[1]}</span>
        <small>${item[2]}</small>
      </div>
    `).join("")}
  </div>
</section>

<section class="details-section">
  <h2>🎯 Uses</h2>

  <div class="info-card">
    ${product.uses.map(x => `<p>✓ ${x}</p>`).join("")}
  </div>
</section>

<section class="details-section">
  <h2>⚙️ Ingredient Functions</h2>

  <div class="info-card">
    <p><strong>Permethrin:</strong> অ্যান্টিপ্যারাসাইটিক active ingredient; mites ও lice-এর বিরুদ্ধে কাজ করে।</p>
    <p><strong>Cetrimide:</strong> antiseptic action প্রদান করে।</p>
    <p><strong>Aloe Vera:</strong> skin-conditioning ও soothing ভূমিকা রাখে।</p>
    <p><strong>Soap Noodles:</strong> সাবান bar-এর মূল base।</p>
    <p><strong>Titanium Dioxide:</strong> colour/opacifying ingredient হিসেবে ব্যবহৃত হয়।</p>
  </div>
</section>

<section class="details-section">
  <h2>🧴 ব্যবহারবিধি</h2>

  <div class="info-card">
    <p>
      পণ্যের লেবেল অথবা qualified healthcare professional-এর
      নির্দেশনা অনুসরণ করুন।
    </p>

    <p class="warning-text">
      ⚠️ নিজে থেকে dose, contact time বা treatment duration পরিবর্তন করবেন না।
    </p>
  </div>
</section>

<section class="details-section">
  <h2>⚠️ সতর্কতা</h2>

  <div class="warning-card">
    ${product.precautions.map(x => `<p>• ${x}</p>`).join("")}
  </div>
</section>

<section class="details-section">
  <h2>Possible Side Effects</h2>

  <div class="info-card">
    ${product.sideEffects.map(x => `<p>• ${x}</p>`).join("")}
  </div>
</section>

<section class="details-section">
  <h2>📦 Storage</h2>

  <div class="info-card">
    <p>Cool and dry place-এ সংরক্ষণ করুন।</p>
  </div>
</section>

<section class="source-card">
  <strong>📌 তথ্যের উৎস</strong>
  <p>
    Publicly available product information এবং pharmacy listing-এর
    ভিত্তিতে তথ্য সংকলন করা হয়েছে। Commercial formulation বা
    manufacturing process হিসেবে এই তথ্য ব্যবহার করা যাবে না।
  </p>
</section>

<section class="disclaimer">
  <strong>⚕ গুরুত্বপূর্ণ Disclaimer</strong>
  <p>
    COSMO FORMULA PRO-এর তথ্য শিক্ষামূলক ও তথ্যগত ব্যবহারের জন্য।
    এটি চিকিৎসকের পরামর্শ বা অনুমোদিত product label-এর বিকল্প নয়।
  </p>
</section>
`;
