const ingredients = [
  {name:"Permethrin",bn:"পারমেথ্রিন",category:"Active Ingredient",function:"Antiparasitic active",uses:"Medicated products for mite and lice infestation",safety:"Use only according to verified product or healthcare guidance."},
  {name:"Cetrimide",bn:"সেট্রিমাইড",category:"Antiseptic / Surfactant",function:"Antiseptic and cleansing role",uses:"Cleansing and antiseptic formulations",safety:"May cause irritation depending on concentration."},
  {name:"Aloe Vera",bn:"অ্যালোভেরা",category:"Botanical / Skin Conditioning",function:"Soothing and skin conditioning",uses:"Soap, cream and lotion products",safety:"Use suitable cosmetic-grade material."},
  {name:"Glycerin",bn:"গ্লিসারিন",category:"Humectant",function:"Moisture retention",uses:"Soap, cream and lotion products",safety:"Use suitable cosmetic-grade material."},
  {name:"Citric Acid",bn:"সিট্রিক অ্যাসিড",category:"pH Adjuster",function:"pH adjustment",uses:"Cosmetic formulations",safety:"Excess concentration may cause irritation."},
  {name:"Sodium Hydroxide",bn:"সোডিয়াম হাইড্রোক্সাইড (NaOH)",category:"Alkali",function:"Saponification / pH adjustment",uses:"Soap making",safety:"CORROSIVE. Use gloves and eye protection."},
  {name:"Ethanol",bn:"ইথানল",category:"Solvent",function:"Solvent",uses:"Selected personal-care formulations",safety:"FLAMMABLE. Keep away from heat and flame."},
  {name:"Titanium Dioxide",bn:"টাইটানিয়াম ডাই-অক্সাইড",category:"Opacifier / Colour",function:"Opacity and colour",uses:"Soap and cosmetic formulations",safety:"Follow product-grade safety requirements."},
  {name:"Soap Noodles",bn:"সোপ নুডলস",category:"Soap Base",function:"Soap base",uses:"Bar soap production",safety:"Follow supplier specifications."}
];
window.ingredients = ingredients;
if(typeof renderIngredients === "function") renderIngredients(ingredients);
